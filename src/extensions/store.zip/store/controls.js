/**
 * WordPress dependencies
 */
import apiFetch from '@wordpress/api-fetch';
import { select } from '@wordpress/data';

const controls = {
	async RECEIVE_GENERAL_SETTINGS() {
		return apiFetch({ path: '/maxi-blocks/v1.0/settings' });
	},
	async SAVE_GENERAL_SETTING(settings) {
		await apiFetch({
			path: '/maxi-blocks/v1.0/settings/',
			method: 'POST',
			data: {
				settings,
			},
		}).catch(err => {
			console.error(
				'Error saving general maxi setting. Code error: ',
				err
			);
		});
	},
	async RECEIVE_BREAKPOINTS() {
		return apiFetch({ path: '/maxi-blocks/v1.0/breakpoints/' });
	},
	async RECEIVE_DEVICE_TYPE() {
		const originalDeviceType = select('maxiBlocks').receiveMaxiDeviceType();

		return originalDeviceType === 'Desktop'
			? 'general'
			: originalDeviceType;
	},
	async CREATE_UNIQUE_ID(blockName) {
		console.log('CREATE_UNIQUE_ID');
		console.log('blockName', blockName);
		await apiFetch({
			path: '/maxi-blocks/v1.0/unique-id/',
			method: 'POST',
			data: { blockName },
		}).catch(err => {
			console.error(
				`Error creating uniqueID for block ${blockName}. Code error: `,
				err
			);
		});
	},
};

export default controls;
